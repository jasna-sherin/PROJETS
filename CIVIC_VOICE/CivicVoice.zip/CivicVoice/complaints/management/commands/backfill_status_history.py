from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from complaints.models import Complaint, ComplaintStatusHistory

User = get_user_model()

class Command(BaseCommand):
    help = 'Backfill status history for existing complaints'

    def handle(self, *args, **options):
        complaints_without_history = Complaint.objects.exclude(
            complaint_id__in=ComplaintStatusHistory.objects.values_list('complaint__complaint_id', flat=True)
        )
        
        created_count = 0
        
        for complaint in complaints_without_history:
            # Create initial status history entry
            # For initial submission, use the same status for both old and new
            # and indicate in remarks that it's the initial submission
            ComplaintStatusHistory.objects.create(
                complaint=complaint,
                old_status='PENDING',  # All complaints start as PENDING
                new_status=complaint.status,
                changed_by=complaint.user,
                changed_at=complaint.created_at,
                remarks='Complaint submitted by user'
            )
            created_count += 1
            
        self.stdout.write(
            self.style.SUCCESS(
                f'Successfully created {created_count} status history entries for existing complaints'
            )
        )