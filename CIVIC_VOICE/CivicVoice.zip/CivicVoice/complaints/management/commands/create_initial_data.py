from django.core.management.base import BaseCommand
from complaints.models import Category

class Command(BaseCommand):
    help = 'Create initial categories for the CivicVoice platform'

    def handle(self, *args, **options):
        categories = [
            {
                'name': 'Healthcare',
                'description': 'Issues related to hospitals, clinics, medical services, and public health facilities'
            },
            {
                'name': 'Education',
                'description': 'Problems with schools, colleges, educational infrastructure, and academic services'
            },
            {
                'name': 'Transport',
                'description': 'Public transportation, roads, traffic management, and commute-related issues'
            },
            {
                'name': 'Water & Sanitation',
                'description': 'Water supply, drainage, sewage, waste management, and cleanliness issues'
            },
            {
                'name': 'Public Works Department (PWD)',
                'description': 'Infrastructure maintenance, construction, road repairs, and public facilities'
            },
            {
                'name': 'Electricity',
                'description': 'Power outages, electrical infrastructure, street lighting, and energy services'
            },
            {
                'name': 'Law & Order',
                'description': 'Police services, public safety, crime prevention, and security issues'
            },
            {
                'name': 'Municipal Services',
                'description': 'Local government services, civic amenities, and municipal administration'
            }
        ]

        created_count = 0
        for category_data in categories:
            category, created = Category.objects.get_or_create(
                name=category_data['name'],
                defaults={'description': category_data['description']}
            )
            if created:
                created_count += 1
                self.stdout.write(
                    self.style.SUCCESS(f'Created category: {category.name}')
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f'Category already exists: {category.name}')
                )

        self.stdout.write(
            self.style.SUCCESS(f'\nCompleted! Created {created_count} new categories.')
        )