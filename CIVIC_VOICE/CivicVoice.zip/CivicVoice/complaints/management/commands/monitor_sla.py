from django.core.management.base import BaseCommand
from django.utils import timezone
from django.core.mail import send_mass_mail
from django.conf import settings
from complaints.models import Complaint, Department, Priority
from datetime import timedelta


class Command(BaseCommand):
    help = 'Monitor SLA compliance and send alerts for breached or at-risk complaints'
    
    def add_arguments(self, parser):
        parser.add_argument(
            '--send-emails',
            action='store_true',
            help='Send email alerts for SLA breaches'
        )
        parser.add_argument(
            '--escalate',
            action='store_true',
            help='Automatically escalate complaints that have breached SLA'
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Show what would be done without making changes'
        )
    
    def handle(self, *args, **options):
        self.dry_run = options['dry_run']
        
        if self.dry_run:
            self.stdout.write(self.style.WARNING('DRY RUN MODE - No changes will be made'))
        
        # Update SLA breach status
        self.update_sla_status()
        
        # Get complaints that need attention
        breached_complaints = self.get_sla_breached_complaints()
        at_risk_complaints = self.get_at_risk_complaints()
        
        # Report findings
        self.report_sla_status(breached_complaints, at_risk_complaints)
        
        # Send email alerts if requested
        if options['send_emails'] and not self.dry_run:
            self.send_sla_alerts(breached_complaints, at_risk_complaints)
        
        # Escalate complaints if requested
        if options['escalate'] and not self.dry_run:
            self.escalate_breached_complaints(breached_complaints)
    
    def update_sla_status(self):
        """Update SLA breach status for all active complaints"""
        self.stdout.write('Updating SLA breach status...')
        
        active_complaints = Complaint.objects.filter(
            priority__isnull=False,
            status__in=['PENDING', 'IN_PROGRESS']
        )
        
        updated_count = 0
        for complaint in active_complaints:
            old_status = complaint.sla_breached
            new_status = complaint.priority.is_sla_breached(complaint.created_at)
            
            if old_status != new_status:
                if not self.dry_run:
                    complaint.sla_breached = new_status
                    complaint.save(update_fields=['sla_breached'])
                updated_count += 1
                
                status_text = "BREACHED" if new_status else "RESTORED"
                self.stdout.write(f"  → {complaint.complaint_id}: SLA {status_text}")
        
        self.stdout.write(
            self.style.SUCCESS(f'Updated SLA status for {updated_count} complaints')
        )
    
    def get_sla_breached_complaints(self):
        """Get complaints that have breached their SLA"""
        return Complaint.objects.filter(
            sla_breached=True,
            status__in=['PENDING', 'IN_PROGRESS']
        ).select_related('priority', 'department', 'user', 'assigned_to')
    
    def get_at_risk_complaints(self):
        """Get complaints that are at risk of breaching SLA (within 2 hours)"""
        at_risk_complaints = []
        
        active_complaints = Complaint.objects.filter(
            priority__isnull=False,
            sla_breached=False,
            status__in=['PENDING', 'IN_PROGRESS']
        ).select_related('priority', 'department', 'user', 'assigned_to')
        
        for complaint in active_complaints:
            sla_deadline = complaint.created_at + timedelta(hours=complaint.priority.sla_hours)
            time_remaining = sla_deadline - timezone.now()
            
            # At risk if less than 2 hours remaining
            if time_remaining.total_seconds() <= 7200:  # 2 hours = 7200 seconds
                at_risk_complaints.append(complaint)
        
        return at_risk_complaints
    
    def report_sla_status(self, breached_complaints, at_risk_complaints):
        """Report SLA status summary"""
        self.stdout.write('\n' + '='*60)
        self.stdout.write(self.style.HTTP_INFO('SLA MONITORING SUMMARY'))
        self.stdout.write('='*60)
        
        # Breached complaints
        self.stdout.write(
            self.style.ERROR(f'\n🚨 SLA BREACHED: {len(breached_complaints)} complaints')
        )
        
        if breached_complaints:
            for complaint in breached_complaints[:10]:  # Show first 10
                age = timezone.now() - complaint.created_at
                self.stdout.write(
                    f"  • {complaint.complaint_id} | {complaint.priority.name} | "
                    f"Age: {age.days}d {age.seconds//3600}h | "
                    f"Dept: {complaint.department.name if complaint.department else 'None'}"
                )
            
            if len(breached_complaints) > 10:
                self.stdout.write(f"  ... and {len(breached_complaints) - 10} more")
        
        # At-risk complaints
        self.stdout.write(
            self.style.WARNING(f'\n⚠️  AT RISK: {len(at_risk_complaints)} complaints')
        )
        
        if at_risk_complaints:
            for complaint in at_risk_complaints[:10]:  # Show first 10
                sla_deadline = complaint.created_at + timedelta(hours=complaint.priority.sla_hours)
                time_remaining = sla_deadline - timezone.now()
                hours_remaining = time_remaining.total_seconds() / 3600
                
                self.stdout.write(
                    f"  • {complaint.complaint_id} | {complaint.priority.name} | "
                    f"Time left: {hours_remaining:.1f}h | "
                    f"Dept: {complaint.department.name if complaint.department else 'None'}"
                )
            
            if len(at_risk_complaints) > 10:
                self.stdout.write(f"  ... and {len(at_risk_complaints) - 10} more")
        
        # Department breakdown
        self.department_breakdown(breached_complaints, at_risk_complaints)
    
    def department_breakdown(self, breached_complaints, at_risk_complaints):
        """Show breakdown by department"""
        dept_stats = {}
        
        all_complaints = list(breached_complaints) + list(at_risk_complaints)
        
        for complaint in all_complaints:
            dept_name = complaint.department.name if complaint.department else 'Unassigned'
            
            if dept_name not in dept_stats:
                dept_stats[dept_name] = {'breached': 0, 'at_risk': 0}
            
            if complaint in breached_complaints:
                dept_stats[dept_name]['breached'] += 1
            else:
                dept_stats[dept_name]['at_risk'] += 1
        
        if dept_stats:
            self.stdout.write(f'\n📊 DEPARTMENT BREAKDOWN:')
            for dept, stats in sorted(dept_stats.items()):
                self.stdout.write(
                    f"  • {dept}: {stats['breached']} breached, {stats['at_risk']} at risk"
                )
    
    def send_sla_alerts(self, breached_complaints, at_risk_complaints):
        """Send email alerts for SLA issues"""
        if not breached_complaints and not at_risk_complaints:
            self.stdout.write('No SLA alerts to send')
            return
        
        self.stdout.write('Sending SLA email alerts...')
        
        # Get department heads and admins
        email_recipients = set()
        
        # Add department heads for affected departments
        departments = set()
        for complaint in list(breached_complaints) + list(at_risk_complaints):
            if complaint.department:
                departments.add(complaint.department)
        
        for dept in departments:
            if dept.email:
                email_recipients.add(dept.email)
        
        # Add admin emails (you can configure this in settings)
        admin_emails = getattr(settings, 'SLA_ALERT_EMAILS', [])
        email_recipients.update(admin_emails)
        
        if not email_recipients:
            self.stdout.write(self.style.WARNING('No email recipients configured'))
            return
        
        # Compose email
        subject = f'SLA Alert: {len(breached_complaints)} breached, {len(at_risk_complaints)} at risk'
        
        message = self.compose_alert_email(breached_complaints, at_risk_complaints)
        
        # Send emails
        emails = []
        for recipient in email_recipients:
            emails.append((subject, message, settings.DEFAULT_FROM_EMAIL, [recipient]))
        
        try:
            send_mass_mail(emails, fail_silently=False)
            self.stdout.write(
                self.style.SUCCESS(f'Sent alerts to {len(email_recipients)} recipients')
            )
        except Exception as e:
            self.stdout.write(
                self.style.ERROR(f'Failed to send emails: {e}')
            )
    
    def compose_alert_email(self, breached_complaints, at_risk_complaints):
        """Compose the alert email content"""
        lines = [
            'SLA MONITORING ALERT',
            '=' * 50,
            '',
            f'Timestamp: {timezone.now().strftime("%Y-%m-%d %H:%M:%S")}',
            '',
        ]
        
        if breached_complaints:
            lines.extend([
                f'🚨 SLA BREACHED ({len(breached_complaints)} complaints):',
                ''
            ])
            
            for complaint in breached_complaints:
                age = timezone.now() - complaint.created_at
                lines.append(
                    f'• {complaint.complaint_id} - {complaint.title[:50]}...'
                    f'\n  Priority: {complaint.priority.name} | '
                    f'Age: {age.days}d {age.seconds//3600}h | '
                    f'Dept: {complaint.department.name if complaint.department else "None"}'
                    f'\n  Assigned to: {complaint.assigned_to.get_full_name() if complaint.assigned_to else "Unassigned"}'
                    f'\n'
                )
        
        if at_risk_complaints:
            lines.extend([
                '',
                f'⚠️ AT RISK ({len(at_risk_complaints)} complaints):',
                ''
            ])
            
            for complaint in at_risk_complaints:
                sla_deadline = complaint.created_at + timedelta(hours=complaint.priority.sla_hours)
                time_remaining = sla_deadline - timezone.now()
                hours_remaining = time_remaining.total_seconds() / 3600
                
                lines.append(
                    f'• {complaint.complaint_id} - {complaint.title[:50]}...'
                    f'\n  Priority: {complaint.priority.name} | '
                    f'Time remaining: {hours_remaining:.1f}h | '
                    f'Dept: {complaint.department.name if complaint.department else "None"}'
                    f'\n'
                )
        
        lines.extend([
            '',
            'Please take immediate action on breached complaints and monitor at-risk items.',
            '',
            'CivicVoice Complaint Management System'
        ])
        
        return '\n'.join(lines)
    
    def escalate_breached_complaints(self, breached_complaints):
        """Automatically escalate complaints that have breached SLA"""
        if not breached_complaints:
            return
        
        self.stdout.write(f'Escalating {len(breached_complaints)} SLA-breached complaints...')
        
        escalated_count = 0
        for complaint in breached_complaints:
            if complaint.status != 'ESCALATED':
                complaint.status = 'ESCALATED'
                complaint.escalated_at = timezone.now()
                complaint.admin_remarks = (
                    f"{complaint.admin_remarks}\n\n"
                    f"[AUTO-ESCALATED] SLA breach detected on {timezone.now().strftime('%Y-%m-%d %H:%M')} "
                    f"after {complaint.age_in_days} days."
                ).strip()
                
                complaint.save()
                escalated_count += 1
                
                self.stdout.write(f"  → Escalated {complaint.complaint_id}")
        
        self.stdout.write(
            self.style.SUCCESS(f'Escalated {escalated_count} complaints')
        )