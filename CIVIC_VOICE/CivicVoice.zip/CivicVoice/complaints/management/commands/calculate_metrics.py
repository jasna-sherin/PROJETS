from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import date, timedelta
from complaints.models import ComplaintMetrics, Complaint, Priority


class Command(BaseCommand):
    help = 'Calculate and update daily complaint metrics'
    
    def add_arguments(self, parser):
        parser.add_argument(
            '--date',
            type=str,
            help='Date to calculate metrics for (YYYY-MM-DD format). Defaults to yesterday.'
        )
        parser.add_argument(
            '--days',
            type=int,
            default=1,
            help='Number of days to calculate metrics for (backwards from date)'
        )
        parser.add_argument(
            '--all',
            action='store_true',
            help='Calculate metrics for all days with complaint data'
        )
    
    def handle(self, *args, **options):
        if options['all']:
            self.calculate_all_metrics()
        else:
            target_date = options['date']
            if target_date:
                try:
                    target_date = timezone.datetime.strptime(target_date, '%Y-%m-%d').date()
                except ValueError:
                    self.stdout.write(
                        self.style.ERROR('Invalid date format. Use YYYY-MM-DD')
                    )
                    return
            else:
                target_date = timezone.now().date() - timedelta(days=1)
            
            days_count = options['days']
            
            for i in range(days_count):
                calc_date = target_date - timedelta(days=i)
                self.calculate_metrics_for_date(calc_date)
        
        self.stdout.write(
            self.style.SUCCESS('Metrics calculation completed successfully!')
        )
    
    def calculate_metrics_for_date(self, target_date):
        """Calculate metrics for a specific date"""
        self.stdout.write(f'Calculating metrics for {target_date}...')
        
        # Calculate the metrics using the model method
        metrics = ComplaintMetrics.calculate_daily_metrics(target_date)
        
        self.stdout.write(
            self.style.SUCCESS(
                f'✓ {target_date}: {metrics.new_complaints} new, '
                f'{metrics.resolved_complaints} resolved, '
                f'{metrics.total_active} total active'
            )
        )
    
    def calculate_all_metrics(self):
        """Calculate metrics for all dates with complaint data"""
        self.stdout.write('Calculating metrics for all dates with complaint data...')
        
        # Get date range from first complaint to today
        first_complaint = Complaint.objects.order_by('created_at').first()
        if not first_complaint:
            self.stdout.write(self.style.WARNING('No complaints found in database'))
            return
        
        start_date = first_complaint.created_at.date()
        end_date = timezone.now().date()
        
        current_date = start_date
        total_days = 0
        
        while current_date <= end_date:
            self.calculate_metrics_for_date(current_date)
            current_date += timedelta(days=1)
            total_days += 1
        
        self.stdout.write(
            self.style.SUCCESS(f'Calculated metrics for {total_days} days')
        )
    
    def check_sla_breaches(self):
        """Update SLA breach status for all complaints"""
        self.stdout.write('Checking SLA breaches...')
        
        complaints_with_priority = Complaint.objects.filter(
            priority__isnull=False,
            status__in=['PENDING', 'IN_PROGRESS']
        )
        
        updated_count = 0
        for complaint in complaints_with_priority:
            old_status = complaint.sla_breached
            complaint.sla_breached = complaint.priority.is_sla_breached(complaint.created_at)
            
            if old_status != complaint.sla_breached:
                complaint.save(update_fields=['sla_breached'])
                updated_count += 1
        
        self.stdout.write(
            self.style.SUCCESS(f'Updated SLA breach status for {updated_count} complaints')
        )