from django.core.management.base import BaseCommand
from django.utils import timezone
from django.db.models import Count, Avg, Q, F
from datetime import date, timedelta
from complaints.models import Complaint, Category, Department, Priority, ComplaintMetrics
import json


class Command(BaseCommand):
    help = 'Generate comprehensive analytics reports'
    
    def add_arguments(self, parser):
        parser.add_argument(
            '--type',
            choices=['summary', 'performance', 'trends', 'sla', 'satisfaction', 'all'],
            default='summary',
            help='Type of report to generate'
        )
        parser.add_argument(
            '--days',
            type=int,
            default=30,
            help='Number of days to include in the report (default: 30)'
        )
        parser.add_argument(
            '--format',
            choices=['table', 'json', 'csv'],
            default='table',
            help='Output format'
        )
        parser.add_argument(
            '--output',
            type=str,
            help='Output file path (optional)'
        )
    
    def handle(self, *args, **options):
        self.format = options['format']
        self.output_file = options['output']
        
        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=options['days'])
        
        self.stdout.write(f'Generating {options["type"]} report for {start_date} to {end_date}...')
        
        report_type = options['type']
        
        if report_type == 'all':
            reports = ['summary', 'performance', 'trends', 'sla', 'satisfaction']
        else:
            reports = [report_type]
        
        all_data = {}
        
        for report in reports:
            data = getattr(self, f'generate_{report}_report')(start_date, end_date)
            all_data[report] = data
            
            if self.format == 'table':
                self.display_report(report, data)
        
        # Save to file if requested
        if self.output_file:
            self.save_to_file(all_data)
    
    def generate_summary_report(self, start_date, end_date):
        """Generate overall summary statistics"""
        queryset = Complaint.objects.filter(
            created_at__date__gte=start_date,
            created_at__date__lte=end_date
        )
        
        total_complaints = queryset.count()
        resolved_complaints = queryset.filter(status='RESOLVED').count()
        escalated_complaints = queryset.filter(status='ESCALATED').count()
        pending_complaints = queryset.filter(status='PENDING').count()
        in_progress_complaints = queryset.filter(status='IN_PROGRESS').count()
        
        # Resolution rate
        resolution_rate = (resolved_complaints / total_complaints * 100) if total_complaints > 0 else 0
        
        # Average resolution time
        avg_resolution = queryset.filter(
            status='RESOLVED',
            resolution_time_hours__isnull=False
        ).aggregate(avg=Avg('resolution_time_hours'))['avg'] or 0
        
        # SLA metrics
        sla_total = queryset.filter(priority__isnull=False).count()
        sla_breached = queryset.filter(sla_breached=True).count()
        sla_compliance = ((sla_total - sla_breached) / sla_total * 100) if sla_total > 0 else 0
        
        return {
            'period': f'{start_date} to {end_date}',
            'total_complaints': total_complaints,
            'resolved_complaints': resolved_complaints,
            'escalated_complaints': escalated_complaints,
            'pending_complaints': pending_complaints,
            'in_progress_complaints': in_progress_complaints,
            'resolution_rate': round(resolution_rate, 2),
            'avg_resolution_hours': round(avg_resolution, 2),
            'sla_compliance_rate': round(sla_compliance, 2),
            'sla_breached_count': sla_breached
        }
    
    def generate_performance_report(self, start_date, end_date):
        """Generate department and category performance metrics"""
        queryset = Complaint.objects.filter(
            created_at__date__gte=start_date,
            created_at__date__lte=end_date
        )
        
        # Department performance
        dept_stats = []
        for dept in Department.objects.filter(is_active=True):
            dept_complaints = queryset.filter(department=dept)
            total = dept_complaints.count()
            
            if total > 0:
                resolved = dept_complaints.filter(status='RESOLVED').count()
                avg_resolution = dept_complaints.filter(
                    status='RESOLVED',
                    resolution_time_hours__isnull=False
                ).aggregate(avg=Avg('resolution_time_hours'))['avg'] or 0
                
                resolution_rate = (resolved / total * 100) if total > 0 else 0
                
                dept_stats.append({
                    'department': dept.name,
                    'total_complaints': total,
                    'resolved_complaints': resolved,
                    'resolution_rate': round(resolution_rate, 2),
                    'avg_resolution_hours': round(avg_resolution, 2)
                })
        
        # Category performance
        category_stats = []
        for category in Category.objects.all():
            cat_complaints = queryset.filter(category=category)
            total = cat_complaints.count()
            
            if total > 0:
                resolved = cat_complaints.filter(status='RESOLVED').count()
                avg_resolution = cat_complaints.filter(
                    status='RESOLVED',
                    resolution_time_hours__isnull=False
                ).aggregate(avg=Avg('resolution_time_hours'))['avg'] or 0
                
                resolution_rate = (resolved / total * 100) if total > 0 else 0
                
                category_stats.append({
                    'category': category.name,
                    'total_complaints': total,
                    'resolved_complaints': resolved,
                    'resolution_rate': round(resolution_rate, 2),
                    'avg_resolution_hours': round(avg_resolution, 2)
                })
        
        return {
            'department_performance': dept_stats,
            'category_performance': category_stats
        }
    
    def generate_trends_report(self, start_date, end_date):
        """Generate daily trends data"""
        daily_stats = []
        current_date = start_date
        
        while current_date <= end_date:
            day_complaints = Complaint.objects.filter(created_at__date=current_date)
            day_resolved = Complaint.objects.filter(resolved_at__date=current_date)
            
            daily_stats.append({
                'date': current_date.strftime('%Y-%m-%d'),
                'new_complaints': day_complaints.count(),
                'resolved_complaints': day_resolved.count()
            })
            
            current_date += timedelta(days=1)
        
        # Weekly aggregates
        weekly_stats = []
        week_start = start_date
        
        while week_start <= end_date:
            week_end = min(week_start + timedelta(days=6), end_date)
            
            week_complaints = Complaint.objects.filter(
                created_at__date__gte=week_start,
                created_at__date__lte=week_end
            )
            week_resolved = Complaint.objects.filter(
                resolved_at__date__gte=week_start,
                resolved_at__date__lte=week_end
            )
            
            weekly_stats.append({
                'week_start': week_start.strftime('%Y-%m-%d'),
                'week_end': week_end.strftime('%Y-%m-%d'),
                'new_complaints': week_complaints.count(),
                'resolved_complaints': week_resolved.count()
            })
            
            week_start += timedelta(days=7)
        
        return {
            'daily_trends': daily_stats,
            'weekly_trends': weekly_stats
        }
    
    def generate_sla_report(self, start_date, end_date):
        """Generate SLA compliance report"""
        queryset = Complaint.objects.filter(
            created_at__date__gte=start_date,
            created_at__date__lte=end_date,
            priority__isnull=False
        )
        
        # SLA by priority level
        priority_sla = []
        for priority in Priority.objects.all():
            priority_complaints = queryset.filter(priority=priority)
            total = priority_complaints.count()
            
            if total > 0:
                breached = priority_complaints.filter(sla_breached=True).count()
                compliance_rate = ((total - breached) / total * 100)
                
                # Calculate average response time (SQLite compatible)
                response_complaints = priority_complaints.filter(first_response_at__isnull=False)
                if response_complaints.exists():
                    total_response_time = 0
                    count = 0
                    for complaint in response_complaints:
                        if complaint.first_response_at and complaint.created_at:
                            delta = complaint.first_response_at - complaint.created_at
                            total_response_time += delta.total_seconds() / 3600
                            count += 1
                    avg_response_hours = total_response_time / count if count > 0 else 0
                else:
                    avg_response_hours = 0
                
                priority_sla.append({
                    'priority': priority.name,
                    'sla_hours': priority.sla_hours,
                    'total_complaints': total,
                    'sla_breached': breached,
                    'compliance_rate': round(compliance_rate, 2),
                    'avg_response_hours': round(avg_response_hours, 2)
                })
        
        # Currently breached complaints
        breached_complaints = []
        current_breached = Complaint.objects.filter(
            sla_breached=True,
            status__in=['PENDING', 'IN_PROGRESS']
        ).select_related('priority', 'department')[:20]  # Top 20
        
        for complaint in current_breached:
            age = timezone.now() - complaint.created_at
            breached_complaints.append({
                'complaint_id': complaint.complaint_id,
                'title': complaint.title[:50],
                'priority': complaint.priority.name if complaint.priority else 'None',
                'department': complaint.department.name if complaint.department else 'None',
                'age_days': age.days,
                'age_hours': age.seconds // 3600
            })
        
        return {
            'priority_sla_breakdown': priority_sla,
            'currently_breached': breached_complaints
        }
    
    def generate_satisfaction_report(self, start_date, end_date):
        """Generate satisfaction and feedback report"""
        from complaints.models import Feedback
        
        queryset = Complaint.objects.filter(
            resolved_at__date__gte=start_date,
            resolved_at__date__lte=end_date,
            status='RESOLVED'
        )
        
        # Overall satisfaction
        feedbacks = Feedback.objects.filter(complaint__in=queryset)
        total_feedback = feedbacks.count()
        
        if total_feedback > 0:
            avg_rating = feedbacks.aggregate(avg=Avg('rating'))['avg']
            rating_distribution = list(feedbacks.values('rating').annotate(
                count=Count('rating')
            ).order_by('rating'))
        else:
            avg_rating = 0
            rating_distribution = []
        
        # Satisfaction by category
        category_satisfaction = []
        for category in Category.objects.all():
            cat_resolved = queryset.filter(category=category)
            cat_feedback = feedbacks.filter(complaint__category=category)
            
            if cat_feedback.exists():
                cat_avg = cat_feedback.aggregate(avg=Avg('rating'))['avg']
                category_satisfaction.append({
                    'category': category.name,
                    'total_resolved': cat_resolved.count(),
                    'feedback_count': cat_feedback.count(),
                    'avg_rating': round(cat_avg, 2)
                })
        
        # Recommendation rate
        recommend_yes = feedbacks.filter(would_recommend=True).count()
        recommend_rate = (recommend_yes / total_feedback * 100) if total_feedback > 0 else 0
        
        return {
            'total_resolved_complaints': queryset.count(),
            'total_feedback_received': total_feedback,
            'feedback_rate': round((total_feedback / queryset.count() * 100), 2) if queryset.count() > 0 else 0,
            'avg_satisfaction_rating': round(avg_rating, 2),
            'rating_distribution': rating_distribution,
            'recommendation_rate': round(recommend_rate, 2),
            'category_satisfaction': category_satisfaction
        }
    
    def display_report(self, report_type, data):
        """Display report data in table format"""
        self.stdout.write(f'\n{"="*60}')
        self.stdout.write(f'{report_type.upper()} REPORT')
        self.stdout.write(f'{"="*60}')
        
        if report_type == 'summary':
            self.display_summary_table(data)
        elif report_type == 'performance':
            self.display_performance_table(data)
        elif report_type == 'trends':
            self.display_trends_table(data)
        elif report_type == 'sla':
            self.display_sla_table(data)
        elif report_type == 'satisfaction':
            self.display_satisfaction_table(data)
    
    def display_summary_table(self, data):
        """Display summary report in table format"""
        self.stdout.write(f'Period: {data["period"]}')
        self.stdout.write(f'Total Complaints: {data["total_complaints"]}')
        self.stdout.write(f'Resolved: {data["resolved_complaints"]} ({data["resolution_rate"]}%)')
        self.stdout.write(f'Pending: {data["pending_complaints"]}')
        self.stdout.write(f'In Progress: {data["in_progress_complaints"]}')
        self.stdout.write(f'Escalated: {data["escalated_complaints"]}')
        self.stdout.write(f'Avg Resolution Time: {data["avg_resolution_hours"]:.2f} hours')
        self.stdout.write(f'SLA Compliance: {data["sla_compliance_rate"]}%')
        self.stdout.write(f'SLA Breached: {data["sla_breached_count"]}')
    
    def display_performance_table(self, data):
        """Display performance report in table format"""
        self.stdout.write('\nDEPARTMENT PERFORMANCE:')
        self.stdout.write('-' * 80)
        self.stdout.write(f'{"Department":<20} {"Total":<8} {"Resolved":<10} {"Rate %":<8} {"Avg Hrs":<8}')
        self.stdout.write('-' * 80)
        
        for dept in data['department_performance']:
            self.stdout.write(
                f'{dept["department"]:<20} {dept["total_complaints"]:<8} '
                f'{dept["resolved_complaints"]:<10} {dept["resolution_rate"]:<8.1f} '
                f'{dept["avg_resolution_hours"]:<8.1f}'
            )
        
        self.stdout.write('\nCATEGORY PERFORMANCE:')
        self.stdout.write('-' * 80)
        self.stdout.write(f'{"Category":<20} {"Total":<8} {"Resolved":<10} {"Rate %":<8} {"Avg Hrs":<8}')
        self.stdout.write('-' * 80)
        
        for cat in data['category_performance']:
            self.stdout.write(
                f'{cat["category"]:<20} {cat["total_complaints"]:<8} '
                f'{cat["resolved_complaints"]:<10} {cat["resolution_rate"]:<8.1f} '
                f'{cat["avg_resolution_hours"]:<8.1f}'
            )
    
    def display_trends_table(self, data):
        """Display trends report in table format"""
        self.stdout.write('\nWEEKLY TRENDS:')
        self.stdout.write('-' * 60)
        self.stdout.write(f'{"Week":<22} {"New":<8} {"Resolved":<10}')
        self.stdout.write('-' * 60)
        
        for week in data['weekly_trends']:
            week_label = f"{week['week_start']} to {week['week_end']}"
            self.stdout.write(
                f'{week_label:<22} {week["new_complaints"]:<8} {week["resolved_complaints"]:<10}'
            )
    
    def display_sla_table(self, data):
        """Display SLA report in table format"""
        self.stdout.write('\nSLA COMPLIANCE BY PRIORITY:')
        self.stdout.write('-' * 80)
        self.stdout.write(f'{"Priority":<15} {"SLA Hrs":<8} {"Total":<8} {"Breached":<10} {"Rate %":<8} {"Avg Resp":<8}')
        self.stdout.write('-' * 80)
        
        for priority in data['priority_sla_breakdown']:
            self.stdout.write(
                f'{priority["priority"]:<15} {priority["sla_hours"]:<8} '
                f'{priority["total_complaints"]:<8} {priority["sla_breached"]:<10} '
                f'{priority["compliance_rate"]:<8.1f} {priority["avg_response_hours"]:<8.1f}'
            )
        
        if data['currently_breached']:
            self.stdout.write('\nCURRENTLY SLA BREACHED (Top 10):')
            self.stdout.write('-' * 100)
            self.stdout.write(f'{"ID":<15} {"Title":<30} {"Priority":<12} {"Dept":<15} {"Age":<8}')
            self.stdout.write('-' * 100)
            
            for complaint in data['currently_breached'][:10]:
                age_str = f"{complaint['age_days']}d {complaint['age_hours']}h"
                self.stdout.write(
                    f'{complaint["complaint_id"]:<15} {complaint["title"]:<30} '
                    f'{complaint["priority"]:<12} {complaint["department"]:<15} {age_str:<8}'
                )
    
    def display_satisfaction_table(self, data):
        """Display satisfaction report in table format"""
        self.stdout.write(f'Total Resolved Complaints: {data["total_resolved_complaints"]}')
        self.stdout.write(f'Feedback Received: {data["total_feedback_received"]} ({data["feedback_rate"]}%)')
        self.stdout.write(f'Average Rating: {data["avg_satisfaction_rating"]}/5')
        self.stdout.write(f'Recommendation Rate: {data["recommendation_rate"]}%')
        
        if data['category_satisfaction']:
            self.stdout.write('\nSATISFACTION BY CATEGORY:')
            self.stdout.write('-' * 70)
            self.stdout.write(f'{"Category":<20} {"Resolved":<10} {"Feedback":<10} {"Avg Rating":<12}')
            self.stdout.write('-' * 70)
            
            for cat in data['category_satisfaction']:
                self.stdout.write(
                    f'{cat["category"]:<20} {cat["total_resolved"]:<10} '
                    f'{cat["feedback_count"]:<10} {cat["avg_rating"]:<12.2f}'
                )
    
    def save_to_file(self, data):
        """Save report data to file"""
        try:
            if self.format == 'json':
                import json
                with open(self.output_file, 'w') as f:
                    json.dump(data, f, indent=2, default=str)
            
            elif self.format == 'csv':
                import csv
                # For CSV, we'll flatten the data structure
                with open(self.output_file, 'w', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow(['Report Type', 'Metric', 'Value'])
                    
                    for report_type, report_data in data.items():
                        if isinstance(report_data, dict):
                            for key, value in report_data.items():
                                if not isinstance(value, (list, dict)):
                                    writer.writerow([report_type, key, value])
            
            self.stdout.write(
                self.style.SUCCESS(f'Report saved to {self.output_file}')
            )
            
        except Exception as e:
            self.stdout.write(
                self.style.ERROR(f'Failed to save report: {e}')
            )