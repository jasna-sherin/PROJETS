from django.core.management.base import BaseCommand, CommandError
from django.utils import timezone
from datetime import timedelta
import logging

from complaints.notifications import (
    NotificationManager, 
    check_and_send_sla_alerts,
    check_and_send_stale_complaint_alerts,
    schedule_daily_summary_emails,
    get_admin_email_list
)
from complaints.models import Complaint, ComplaintMetrics

logger = logging.getLogger(__name__)

class Command(BaseCommand):
    help = 'Send automated notifications and perform maintenance tasks'

    def add_arguments(self, parser):
        parser.add_argument(
            '--sla-alerts',
            action='store_true',
            help='Send SLA breach alert emails',
        )
        parser.add_argument(
            '--stale-alerts',
            action='store_true',
            help='Send stale complaint alert emails',
        )
        parser.add_argument(
            '--daily-summary',
            action='store_true',
            help='Send daily summary emails',
        )
        parser.add_argument(
            '--calculate-metrics',
            action='store_true',
            help='Calculate daily metrics',
        )
        parser.add_argument(
            '--all',
            action='store_true',
            help='Run all notification tasks',
        )
        parser.add_argument(
            '--date',
            type=str,
            help='Date for metrics calculation (YYYY-MM-DD format)',
        )

    def handle(self, *args, **options):
        if options['all']:
            options['sla_alerts'] = True
            options['stale_alerts'] = True
            options['daily_summary'] = True
            options['calculate_metrics'] = True

        if not any([options['sla_alerts'], options['stale_alerts'], 
                   options['daily_summary'], options['calculate_metrics']]):
            raise CommandError('You must specify at least one task to run. Use --help for options.')

        # Calculate metrics first if requested
        if options['calculate_metrics']:
            self.calculate_metrics(options.get('date'))

        # Send SLA breach alerts
        if options['sla_alerts']:
            self.send_sla_alerts()

        # Send stale complaint alerts  
        if options['stale_alerts']:
            self.send_stale_alerts()

        # Send daily summary
        if options['daily_summary']:
            self.send_daily_summary()

        self.stdout.write(
            self.style.SUCCESS('Successfully completed notification tasks')
        )

    def calculate_metrics(self, date_str=None):
        """Calculate daily metrics"""
        try:
            if date_str:
                from datetime import datetime
                target_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            else:
                target_date = timezone.now().date()

            self.stdout.write(f'Calculating metrics for {target_date}...')
            
            metrics = ComplaintMetrics.calculate_daily_metrics(target_date)
            
            self.stdout.write(
                self.style.SUCCESS(
                    f'Metrics calculated: {metrics.new_complaints} new, '
                    f'{metrics.resolved_complaints} resolved'
                )
            )
            
        except Exception as e:
            logger.error(f'Error calculating metrics: {e}')
            raise CommandError(f'Failed to calculate metrics: {e}')

    def send_sla_alerts(self):
        """Send SLA breach alert emails"""
        try:
            self.stdout.write('Checking for SLA breaches...')
            
            # Get SLA breached complaints
            breached_complaints = Complaint.objects.filter(
                sla_breached=True,
                status__in=['PENDING', 'IN_PROGRESS']
            ).select_related('user', 'category', 'priority')
            
            count = breached_complaints.count()
            
            if count > 0:
                check_and_send_sla_alerts()
                self.stdout.write(
                    self.style.WARNING(f'SLA breach alerts sent for {count} complaints')
                )
            else:
                self.stdout.write(
                    self.style.SUCCESS('No SLA breaches found')
                )
                
        except Exception as e:
            logger.error(f'Error sending SLA alerts: {e}')
            raise CommandError(f'Failed to send SLA alerts: {e}')

    def send_stale_alerts(self):
        """Send stale complaint alert emails"""
        try:
            self.stdout.write('Checking for stale complaints...')
            
            # Get stale complaints (no update for 7+ days)
            stale_threshold = timezone.now() - timedelta(days=7)
            stale_complaints = Complaint.objects.filter(
                updated_at__lte=stale_threshold,
                status__in=['PENDING', 'IN_PROGRESS']
            )
            
            count = stale_complaints.count()
            
            if count > 0:
                check_and_send_stale_complaint_alerts()
                self.stdout.write(
                    self.style.WARNING(f'Stale complaint alerts sent for {count} complaints')
                )
            else:
                self.stdout.write(
                    self.style.SUCCESS('No stale complaints found')
                )
                
        except Exception as e:
            logger.error(f'Error sending stale alerts: {e}')
            raise CommandError(f'Failed to send stale alerts: {e}')

    def send_daily_summary(self):
        """Send daily summary emails"""
        try:
            self.stdout.write('Sending daily summary emails...')
            
            admin_emails = get_admin_email_list()
            
            if admin_emails:
                schedule_daily_summary_emails()
                self.stdout.write(
                    self.style.SUCCESS(
                        f'Daily summary emails sent to {len(admin_emails)} administrators'
                    )
                )
            else:
                self.stdout.write(
                    self.style.WARNING('No admin email addresses found')
                )
                
        except Exception as e:
            logger.error(f'Error sending daily summary: {e}')
            raise CommandError(f'Failed to send daily summary: {e}')

    def get_notification_stats(self):
        """Get statistics about notifications to be sent"""
        stats = {
            'sla_breached': Complaint.objects.filter(
                sla_breached=True,
                status__in=['PENDING', 'IN_PROGRESS']
            ).count(),
            'stale_complaints': Complaint.objects.filter(
                updated_at__lte=timezone.now() - timedelta(days=7),
                status__in=['PENDING', 'IN_PROGRESS']
            ).count(),
            'unassigned': Complaint.objects.filter(
                assigned_to__isnull=True,
                status='PENDING'
            ).count(),
            'admin_emails': len(get_admin_email_list()),
        }
        
        return stats