from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models import Avg
import uuid
from datetime import datetime, timedelta

class Category(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name_plural = "Categories"
    
    def __str__(self):
        return self.name

class Department(models.Model):
    """Department responsible for handling complaints"""
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    email = models.EmailField(help_text="Email for department notifications")
    phone = models.CharField(max_length=20, blank=True)
    head = models.CharField(max_length=100, help_text="Department head name")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.name
    
    def get_active_complaints_count(self):
        return self.complaints.exclude(status='RESOLVED').count()
    
    def get_avg_resolution_time(self):
        """Get average resolution time for resolved complaints in days"""
        resolved = self.complaints.filter(status='RESOLVED', resolved_at__isnull=False)
        if not resolved.exists():
            return 0
        
        total_days = 0
        for complaint in resolved:
            delta = complaint.resolved_at - complaint.created_at
            total_days += delta.days
        
        return round(total_days / resolved.count(), 2)

class Priority(models.Model):
    """Priority levels for complaints"""
    PRIORITY_CHOICES = [
        ('LOW', 'Low'),
        ('MEDIUM', 'Medium'),
        ('HIGH', 'High'),
        ('CRITICAL', 'Critical'),
    ]
    
    level = models.CharField(max_length=10, choices=PRIORITY_CHOICES, unique=True)
    name = models.CharField(max_length=50)
    description = models.TextField(blank=True)
    sla_hours = models.IntegerField(help_text="SLA in hours for this priority level")
    color_code = models.CharField(max_length=7, default="#007bff", help_text="Hex color code for UI")
    
    class Meta:
        verbose_name_plural = "Priorities"
    
    def __str__(self):
        return f"{self.name} ({self.level})"
    
    def is_sla_breached(self, created_at):
        """Check if SLA is breached for a complaint created at given time"""
        sla_deadline = created_at + timedelta(hours=self.sla_hours)
        return timezone.now() > sla_deadline

class Complaint(models.Model):
    STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('IN_PROGRESS', 'In Progress'),
        ('RESOLVED', 'Resolved'),
        ('CLOSED', 'Closed'),
        ('ESCALATED', 'Escalated'),
    ]
    
    URGENCY_CHOICES = [
        ('LOW', 'Low'),
        ('MEDIUM', 'Medium'),
        ('HIGH', 'High'),
        ('URGENT', 'Urgent'),
    ]
    
    # Basic fields
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='complaints')
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='complaints')
    department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True, blank=True, related_name='complaints')
    priority = models.ForeignKey(Priority, on_delete=models.SET_NULL, null=True, blank=True)
    
    complaint_id = models.CharField(max_length=25, unique=True, editable=False)
    title = models.CharField(max_length=200)
    description = models.TextField()
    location = models.CharField(max_length=200)
    
    # Status and workflow fields
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')
    urgency = models.CharField(max_length=10, choices=URGENCY_CHOICES, default='MEDIUM')
    admin_remarks = models.TextField(blank=True, null=True)
    assigned_to = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='assigned_complaints')
    
    # Analytics and tracking fields
    first_response_at = models.DateTimeField(null=True, blank=True, help_text="When admin first responded")
    in_progress_at = models.DateTimeField(null=True, blank=True, help_text="When status changed to In Progress")
    resolved_at = models.DateTimeField(null=True, blank=True, help_text="When complaint was resolved")
    closed_at = models.DateTimeField(null=True, blank=True, help_text="When complaint was closed")
    escalated_at = models.DateTimeField(null=True, blank=True, help_text="When complaint was escalated")
    
    sla_breached = models.BooleanField(default=False, help_text="Whether SLA was breached")
    resolution_time_hours = models.FloatField(null=True, blank=True, help_text="Total resolution time in hours")
    satisfaction_score = models.IntegerField(null=True, blank=True, help_text="Derived from feedback rating")
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def save(self, *args, **kwargs):
        # Generate complaint ID if not exists
        if not self.complaint_id:
            now = datetime.now()
            date_part = now.strftime("%Y%m%d")
            random_id = str(uuid.uuid4().hex[:6]).upper()
            self.complaint_id = f"CV{date_part}-{random_id}"
        
        # Track status changes and analytics
        if self.pk:  # Existing record
            old_instance = Complaint.objects.get(pk=self.pk)
            
            # Track status change timestamps
            if old_instance.status != self.status:
                now = timezone.now()
                
                if self.status == 'IN_PROGRESS' and not self.in_progress_at:
                    self.in_progress_at = now
                elif self.status == 'RESOLVED' and not self.resolved_at:
                    self.resolved_at = now
                    # Calculate resolution time
                    if self.created_at:
                        delta = now - self.created_at
                        self.resolution_time_hours = delta.total_seconds() / 3600
                elif self.status == 'CLOSED' and not self.closed_at:
                    self.closed_at = now
                elif self.status == 'ESCALATED' and not self.escalated_at:
                    self.escalated_at = now
            
            # Track first response
            if not old_instance.admin_remarks and self.admin_remarks and not self.first_response_at:
                self.first_response_at = timezone.now()
        
        # Check SLA breach
        if self.priority and not self.sla_breached:
            self.sla_breached = self.priority.is_sla_breached(self.created_at)
        
        super().save(*args, **kwargs)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.complaint_id} - {self.title}"
    
    @property
    def age_in_days(self):
        """Get complaint age in days"""
        return (timezone.now() - self.created_at).days
    
    @property
    def response_time_hours(self):
        """Get first response time in hours"""
        if self.first_response_at:
            delta = self.first_response_at - self.created_at
            return round(delta.total_seconds() / 3600, 2)
        return None
    
    @property
    def is_overdue(self):
        """Check if complaint is overdue based on priority SLA"""
        if self.priority and self.status not in ['RESOLVED', 'CLOSED']:
            return self.priority.is_sla_breached(self.created_at)
        return False
    
    @property
    def time_to_resolve_hours(self):
        """Get time taken to resolve in hours"""
        if self.resolved_at:
            delta = self.resolved_at - self.created_at
            return round(delta.total_seconds() / 3600, 2)
        return None
    
    def get_status_color(self):
        """Get color code for status"""
        colors = {
            'PENDING': '#ffc107',  # Warning yellow
            'IN_PROGRESS': '#007bff',  # Primary blue
            'RESOLVED': '#28a745',  # Success green
            'CLOSED': '#6c757d',  # Secondary gray
            'ESCALATED': '#dc3545',  # Danger red
        }
        return colors.get(self.status, '#6c757d')
    
    def get_priority_color(self):
        """Get color code for priority"""
        if self.priority:
            return self.priority.color_code
        return '#6c757d'
    
    @classmethod
    def get_analytics_summary(cls, queryset=None):
        """Get comprehensive analytics summary"""
        if queryset is None:
            queryset = cls.objects.all()
        
        total = queryset.count()
        if total == 0:
            return {}
        
        resolved = queryset.filter(status='RESOLVED')
        avg_resolution_time = resolved.aggregate(avg=Avg('resolution_time_hours'))['avg'] or 0
        
        return {
            'total_complaints': total,
            'pending': queryset.filter(status='PENDING').count(),
            'in_progress': queryset.filter(status='IN_PROGRESS').count(),
            'resolved': resolved.count(),
            'escalated': queryset.filter(status='ESCALATED').count(),
            'avg_resolution_hours': round(avg_resolution_time, 2),
            'sla_breached_count': queryset.filter(sla_breached=True).count(),
            'satisfaction_avg': queryset.filter(satisfaction_score__isnull=False).aggregate(avg=Avg('satisfaction_score'))['avg'] or 0,
        }

class Feedback(models.Model):
    RATING_CHOICES = [
        (1, 'Poor'),
        (2, 'Fair'),
        (3, 'Good'),
        (4, 'Very Good'),
        (5, 'Excellent'),
    ]
    
    complaint = models.OneToOneField(Complaint, on_delete=models.CASCADE)
    rating = models.IntegerField(choices=RATING_CHOICES)
    comments = models.TextField(blank=True)
    would_recommend = models.BooleanField(default=True, help_text="Would recommend the service")
    created_at = models.DateTimeField(auto_now_add=True)
    
    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        # Update complaint's satisfaction score
        self.complaint.satisfaction_score = self.rating
        self.complaint.save(update_fields=['satisfaction_score'])
    
    def __str__(self):
        return f"Feedback for {self.complaint.complaint_id} - {self.get_rating_display()}"

class ComplaintStatusHistory(models.Model):
    """Track status change history for complaints"""
    complaint = models.ForeignKey(Complaint, on_delete=models.CASCADE, related_name='status_history')
    old_status = models.CharField(max_length=20, choices=Complaint.STATUS_CHOICES)
    new_status = models.CharField(max_length=20, choices=Complaint.STATUS_CHOICES)
    changed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    remarks = models.TextField(blank=True)
    changed_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-changed_at']
        verbose_name_plural = "Complaint Status Histories"
    
    def __str__(self):
        return f"{self.complaint.complaint_id}: {self.old_status} → {self.new_status}"

class ComplaintMetrics(models.Model):
    """Daily metrics aggregation for performance tracking"""
    date = models.DateField(unique=True)
    
    # Daily counts
    new_complaints = models.IntegerField(default=0)
    resolved_complaints = models.IntegerField(default=0)
    escalated_complaints = models.IntegerField(default=0)
    total_active = models.IntegerField(default=0)
    
    # Performance metrics
    avg_response_time_hours = models.FloatField(null=True, blank=True)
    avg_resolution_time_hours = models.FloatField(null=True, blank=True)
    sla_compliance_rate = models.FloatField(null=True, blank=True)  # Percentage
    satisfaction_score = models.FloatField(null=True, blank=True)
    
    # Category breakdown (JSON field would be better, but keeping it simple)
    top_category = models.CharField(max_length=100, blank=True)
    top_category_count = models.IntegerField(default=0)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-date']
        verbose_name_plural = "Daily Complaint Metrics"
    
    def __str__(self):
        return f"Metrics for {self.date}"
    
    @classmethod
    def calculate_daily_metrics(cls, target_date=None):
        """Calculate and save daily metrics"""
        if target_date is None:
            target_date = timezone.now().date()
        
        # Get complaints for the day
        day_complaints = Complaint.objects.filter(created_at__date=target_date)
        resolved_complaints = Complaint.objects.filter(resolved_at__date=target_date)
        escalated_complaints = Complaint.objects.filter(escalated_at__date=target_date)
        
        # Calculate metrics
        new_count = day_complaints.count()
        resolved_count = resolved_complaints.count()
        escalated_count = escalated_complaints.count()
        total_active = Complaint.objects.exclude(status__in=['RESOLVED', 'CLOSED']).count()
        
        # Response and resolution times (SQLite compatible)
        response_complaints = day_complaints.filter(first_response_at__isnull=False)
        if response_complaints.exists():
            total_response_time = 0
            count = 0
            for complaint in response_complaints:
                if complaint.first_response_at and complaint.created_at:
                    delta = complaint.first_response_at - complaint.created_at
                    total_response_time += delta.total_seconds() / 3600
                    count += 1
            avg_response = total_response_time / count if count > 0 else 0
        else:
            avg_response = None
        
        avg_resolution = resolved_complaints.aggregate(
            avg=Avg('resolution_time_hours')
        )['avg']
        
        # SLA compliance
        sla_total = day_complaints.filter(priority__isnull=False).count()
        sla_compliant = day_complaints.filter(sla_breached=False, priority__isnull=False).count()
        sla_rate = (sla_compliant / sla_total * 100) if sla_total > 0 else None
        
        # Satisfaction score
        satisfaction = Feedback.objects.filter(
            complaint__resolved_at__date=target_date
        ).aggregate(avg=Avg('rating'))['avg']
        
        # Top category
        top_cat = day_complaints.values('category__name').annotate(
            count=models.Count('id')
        ).order_by('-count').first()
        
        # Create or update metrics
        metrics, created = cls.objects.update_or_create(
            date=target_date,
            defaults={
                'new_complaints': new_count,
                'resolved_complaints': resolved_count,
                'escalated_complaints': escalated_count,
                'total_active': total_active,
                'avg_response_time_hours': avg_response,
                'avg_resolution_time_hours': avg_resolution,
                'sla_compliance_rate': sla_rate,
                'satisfaction_score': satisfaction,
                'top_category': top_cat['category__name'] if top_cat else '',
                'top_category_count': top_cat['count'] if top_cat else 0,
            }
        )
        
        return metrics
