from django.core.mail import send_mail, EmailMultiAlternatives
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from django.conf import settings
from django.utils import timezone
from datetime import datetime, timedelta
import logging
from typing import List, Dict, Optional

logger = logging.getLogger(__name__)

class NotificationManager:
    """Enhanced notification management system for CivicVoice"""
    
    @staticmethod
    def send_complaint_submitted_email(complaint):
        """Send email notification when complaint is submitted"""
        try:
            subject = f'Complaint Submitted Successfully - {complaint.complaint_id}'
            
            # HTML email template
            html_content = render_to_string('emails/complaint_submitted.html', {
                'complaint': complaint,
                'user': complaint.user,
                'tracking_url': f"{settings.SITE_URL}/complaints/track/",
            })
            
            # Plain text version
            text_content = render_to_string('emails/complaint_submitted.txt', {
                'complaint': complaint,
                'user': complaint.user,
                'tracking_url': f"{settings.SITE_URL}/complaints/track/",
            })
            
            msg = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[complaint.user.email]
            )
            msg.attach_alternative(html_content, "text/html")
            
            msg.send()
            logger.info(f"Complaint submission email sent for {complaint.complaint_id}")
            
        except Exception as e:
            logger.error(f"Failed to send complaint submission email: {e}")

    @staticmethod
    def send_status_update_email(complaint, old_status, admin_user=None):
        """Send email notification when complaint status changes"""
        try:
            subject = f'Complaint Status Update - {complaint.complaint_id}'
            
            html_content = render_to_string('emails/status_update.html', {
                'complaint': complaint,
                'old_status': old_status,
                'admin_user': admin_user,
                'status_color': complaint.get_status_color(),
                'complaint_url': f"{settings.SITE_URL}/complaints/{complaint.complaint_id}/",
            })
            
            text_content = render_to_string('emails/status_update.txt', {
                'complaint': complaint,
                'old_status': old_status,
                'admin_user': admin_user,
                'complaint_url': f"{settings.SITE_URL}/complaints/{complaint.complaint_id}/",
            })
            
            msg = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[complaint.user.email]
            )
            msg.attach_alternative(html_content, "text/html")
            
            # CC relevant department if assigned
            cc_emails = []
            if complaint.department and complaint.department.email:
                cc_emails.append(complaint.department.email)
            if complaint.assigned_to and complaint.assigned_to.email:
                cc_emails.append(complaint.assigned_to.email)
            
            if cc_emails:
                msg.cc = cc_emails
            
            msg.send()
            logger.info(f"Status update email sent for {complaint.complaint_id}")
            
        except Exception as e:
            logger.error(f"Failed to send status update email: {e}")

    @staticmethod
    def send_admin_alert_email(alert_type: str, complaints: List, recipient_emails: List[str]):
        """Send alert emails to admin staff"""
        try:
            alert_configs = {
                'sla_breach': {
                    'subject': 'SLA Breach Alert - Urgent Action Required',
                    'template': 'emails/admin_sla_breach_alert.html',
                    'priority': 'high'
                },
                'stale_complaints': {
                    'subject': 'Stale Complaints Alert - Review Required', 
                    'template': 'emails/admin_stale_complaints.html',
                    'priority': 'medium'
                },
                'unassigned_complaints': {
                    'subject': 'Unassigned Complaints - Assignment Needed',
                    'template': 'emails/admin_unassigned_complaints.html', 
                    'priority': 'medium'
                }
            }
            
            if alert_type not in alert_configs:
                logger.warning(f"Unknown alert type: {alert_type}")
                return
            
            config = alert_configs[alert_type]
            
            html_content = render_to_string(config['template'], {
                'complaints': complaints,
                'alert_count': len(complaints),
                'dashboard_url': f"{settings.SITE_URL}/admin/dashboard/",
                'priority': config['priority']
            })
            
            # Plain text version
            text_content = strip_tags(html_content)
            
            for email in recipient_emails:
                msg = EmailMultiAlternatives(
                    subject=config['subject'],
                    body=text_content,
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    to=[email]
                )
                msg.attach_alternative(html_content, "text/html")
                
                # Set priority headers
                if config['priority'] == 'high':
                    msg.extra_headers['X-Priority'] = '1'
                    msg.extra_headers['Importance'] = 'high'
                
                msg.send()
            
            logger.info(f"Admin alert email sent for {alert_type} to {len(recipient_emails)} recipients")
            
        except Exception as e:
            logger.error(f"Failed to send admin alert email: {e}")

    @staticmethod
    def send_daily_summary_email(recipient_emails: List[str], date: Optional[datetime] = None):
        """Send daily summary email to admin staff"""
        try:
            if date is None:
                date = timezone.now().date()
            
            from .models import Complaint, ComplaintMetrics
            
            # Get daily metrics
            metrics = ComplaintMetrics.objects.filter(date=date).first()
            if not metrics:
                metrics = ComplaintMetrics.calculate_daily_metrics(date)
            
            # Get recent complaints
            recent_complaints = Complaint.objects.filter(
                created_at__date=date
            ).select_related('user', 'category', 'priority')[:10]
            
            # Get critical items
            critical_items = {
                'sla_breached': Complaint.objects.filter(
                    sla_breached=True,
                    status__in=['PENDING', 'IN_PROGRESS']
                ).count(),
                'unassigned': Complaint.objects.filter(
                    assigned_to__isnull=True,
                    status='PENDING'
                ).count(),
                'escalated_today': Complaint.objects.filter(
                    escalated_at__date=date
                ).count(),
            }
            
            subject = f'CivicVoice Daily Summary - {date.strftime("%B %d, %Y")}'
            
            html_content = render_to_string('emails/daily_summary.html', {
                'date': date,
                'metrics': metrics,
                'recent_complaints': recent_complaints,
                'critical_items': critical_items,
                'dashboard_url': f"{settings.SITE_URL}/admin/dashboard/",
            })
            
            text_content = render_to_string('emails/daily_summary.txt', {
                'date': date,
                'metrics': metrics,
                'recent_complaints': recent_complaints,
                'critical_items': critical_items,
                'dashboard_url': f"{settings.SITE_URL}/admin/dashboard/",
            })
            
            for email in recipient_emails:
                msg = EmailMultiAlternatives(
                    subject=subject,
                    body=text_content,
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    to=[email]
                )
                msg.attach_alternative(html_content, "text/html")
                msg.send()
            
            logger.info(f"Daily summary email sent to {len(recipient_emails)} recipients")
            
        except Exception as e:
            logger.error(f"Failed to send daily summary email: {e}")

    @staticmethod
    def send_feedback_notification(feedback):
        """Send notification when feedback is submitted"""
        try:
            # Only send if rating is poor (1-2 stars)
            if feedback.rating > 2:
                return
                
            subject = f'Poor Feedback Alert - {feedback.complaint.complaint_id}'
            
            # Get relevant staff emails
            recipient_emails = []
            if feedback.complaint.assigned_to and feedback.complaint.assigned_to.email:
                recipient_emails.append(feedback.complaint.assigned_to.email)
            if feedback.complaint.department and feedback.complaint.department.email:
                recipient_emails.append(feedback.complaint.department.email)
            
            if not recipient_emails:
                # Fallback to admin emails
                from django.contrib.auth.models import User
                recipient_emails = list(User.objects.filter(
                    is_staff=True, is_active=True
                ).values_list('email', flat=True))
            
            html_content = render_to_string('emails/poor_feedback_alert.html', {
                'feedback': feedback,
                'complaint': feedback.complaint,
                'rating_stars': '★' * feedback.rating + '☆' * (5 - feedback.rating),
            })
            
            text_content = strip_tags(html_content)
            
            for email in recipient_emails:
                if email:  # Ensure email is not empty
                    msg = EmailMultiAlternatives(
                        subject=subject,
                        body=text_content,
                        from_email=settings.DEFAULT_FROM_EMAIL,
                        to=[email]
                    )
                    msg.attach_alternative(html_content, "text/html")
                    msg.send()
            
            logger.info(f"Poor feedback notification sent for {feedback.complaint.complaint_id}")
            
        except Exception as e:
            logger.error(f"Failed to send feedback notification: {e}")

    @staticmethod
    def send_assignment_notification(complaint, assigned_to, assigned_by=None):
        """Send notification when complaint is assigned to staff member"""
        try:
            if not assigned_to.email:
                return
                
            subject = f'New Complaint Assignment - {complaint.complaint_id}'
            
            html_content = render_to_string('emails/assignment_notification.html', {
                'complaint': complaint,
                'assigned_to': assigned_to,
                'assigned_by': assigned_by,
                'priority_color': complaint.get_priority_color() if complaint.priority else '#6c757d',
                'complaint_url': f"{settings.SITE_URL}/admin/complaints/{complaint.complaint_id}/",
            })
            
            text_content = render_to_string('emails/assignment_notification.txt', {
                'complaint': complaint,
                'assigned_to': assigned_to,
                'assigned_by': assigned_by,
                'complaint_url': f"{settings.SITE_URL}/admin/complaints/{complaint.complaint_id}/",
            })
            
            msg = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=settings.DEFAULT_FROM_EMAIL,
                to=[assigned_to.email]
            )
            msg.attach_alternative(html_content, "text/html")
            
            # Set priority if complaint is high priority
            if complaint.priority and complaint.priority.level in ['HIGH', 'CRITICAL']:
                msg.extra_headers['X-Priority'] = '1'
                msg.extra_headers['Importance'] = 'high'
            
            msg.send()
            logger.info(f"Assignment notification sent to {assigned_to.email}")
            
        except Exception as e:
            logger.error(f"Failed to send assignment notification: {e}")

# SMS Notification Support (optional - requires Twilio or similar)
class SMSNotificationManager:
    """SMS notification support for critical alerts"""
    
    def __init__(self):
        self.enabled = getattr(settings, 'SMS_NOTIFICATIONS_ENABLED', False)
        if self.enabled:
            self.account_sid = getattr(settings, 'TWILIO_ACCOUNT_SID', None)
            self.auth_token = getattr(settings, 'TWILIO_AUTH_TOKEN', None)
            self.from_number = getattr(settings, 'TWILIO_FROM_NUMBER', None)
    
    def send_critical_alert_sms(self, complaint, phone_numbers: List[str]):
        """Send SMS for critical complaints"""
        if not self.enabled or not phone_numbers:
            return
            
        try:
            from twilio.rest import Client
            client = Client(self.account_sid, self.auth_token)
            
            message_body = (
                f"CRITICAL: New complaint {complaint.complaint_id} requires immediate attention. "
                f"Priority: {complaint.priority.name if complaint.priority else 'High'}. "
                f"Category: {complaint.category.name}."
            )
            
            for phone in phone_numbers:
                message = client.messages.create(
                    body=message_body,
                    from_=self.from_number,
                    to=phone
                )
                logger.info(f"Critical alert SMS sent to {phone}: {message.sid}")
                
        except ImportError:
            logger.warning("Twilio not installed. SMS notifications disabled.")
        except Exception as e:
            logger.error(f"Failed to send SMS notification: {e}")

# Utility functions for notification management
def get_admin_email_list() -> List[str]:
    """Get list of admin emails for notifications"""
    from django.contrib.auth.models import User
    return list(User.objects.filter(
        is_staff=True, 
        is_active=True,
        email__isnull=False
    ).exclude(email='').values_list('email', flat=True))

def should_send_notification(complaint, notification_type: str) -> bool:
    """Determine if notification should be sent based on complaint and type"""
    
    # Notification rules
    rules = {
        'status_change': True,  # Always send status change notifications
        'assignment': True,     # Always send assignment notifications
        'sla_breach': True,     # Always send SLA breach alerts
        'daily_summary': complaint.created_at.date() >= (timezone.now().date() - timedelta(days=1)),
        'feedback_alert': True, # Send feedback alerts for poor ratings
    }
    
    return rules.get(notification_type, False)

# Auto-notification scheduler functions (can be used with Celery)
def schedule_daily_summary_emails():
    """Schedule daily summary emails (to be called by cron job or Celery)"""
    admin_emails = get_admin_email_list()
    if admin_emails:
        NotificationManager.send_daily_summary_email(admin_emails)

def check_and_send_sla_alerts():
    """Check for SLA breaches and send alerts"""
    from .models import Complaint
    
    # Get SLA breached complaints
    breached_complaints = Complaint.objects.filter(
        sla_breached=True,
        status__in=['PENDING', 'IN_PROGRESS']
    ).select_related('user', 'category', 'priority')[:20]  # Limit to 20 for email
    
    if breached_complaints:
        admin_emails = get_admin_email_list()
        NotificationManager.send_admin_alert_email(
            'sla_breach', 
            list(breached_complaints), 
            admin_emails
        )

def check_and_send_stale_complaint_alerts():
    """Check for stale complaints and send alerts"""
    from .models import Complaint
    
    # Get stale complaints (no update for 7+ days)
    stale_threshold = timezone.now() - timedelta(days=7)
    stale_complaints = Complaint.objects.filter(
        updated_at__lte=stale_threshold,
        status__in=['PENDING', 'IN_PROGRESS']
    ).select_related('user', 'category')[:20]
    
    if stale_complaints:
        admin_emails = get_admin_email_list()
        NotificationManager.send_admin_alert_email(
            'stale_complaints',
            list(stale_complaints),
            admin_emails
        )