from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe
from django.db.models import Count, Avg, Q
from django.utils import timezone
from .models import (
    Category, Complaint, Feedback, Department, Priority, 
    ComplaintStatusHistory, ComplaintMetrics
)

# Inline admin classes
class ComplaintStatusHistoryInline(admin.TabularInline):
    model = ComplaintStatusHistory
    extra = 0
    readonly_fields = ['changed_at']
    fields = ['old_status', 'new_status', 'changed_by', 'remarks', 'changed_at']
    
class FeedbackInline(admin.StackedInline):
    model = Feedback
    extra = 0
    readonly_fields = ['created_at']

@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ['name', 'head', 'email', 'active_complaints_count', 'avg_resolution_time', 'is_active']
    list_filter = ['is_active', 'created_at']
    search_fields = ['name', 'head', 'email']
    readonly_fields = ['created_at']
    
    def active_complaints_count(self, obj):
        count = obj.get_active_complaints_count()
        if count > 10:
            return format_html('<span style="color: red; font-weight: bold;">{}</span>', count)
        elif count > 5:
            return format_html('<span style="color: orange; font-weight: bold;">{}</span>', count)
        return count
    active_complaints_count.short_description = 'Active Complaints'
    
    def avg_resolution_time(self, obj):
        avg_time = obj.get_avg_resolution_time()
        if avg_time > 7:  # More than 7 days
            return format_html('<span style="color: red;">{} days</span>', avg_time)
        elif avg_time > 3:  # More than 3 days
            return format_html('<span style="color: orange;">{} days</span>', avg_time)
        return f"{avg_time} days" if avg_time > 0 else "N/A"
    avg_resolution_time.short_description = 'Avg Resolution Time'

@admin.register(Priority)
class PriorityAdmin(admin.ModelAdmin):
    list_display = ['name', 'level', 'sla_hours', 'color_preview', 'complaint_count']
    list_filter = ['level']
    search_fields = ['name', 'level']
    ordering = ['level']
    
    def color_preview(self, obj):
        return format_html(
            '<span style="display: inline-block; width: 20px; height: 20px; background-color: {}; border: 1px solid #ccc;"></span>',
            obj.color_code
        )
    color_preview.short_description = 'Color'
    
    def complaint_count(self, obj):
        return obj.complaint_set.count()
    complaint_count.short_description = 'Total Complaints'

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'description', 'complaint_count', 'avg_resolution_time', 'created_at']
    search_fields = ['name', 'description']
    readonly_fields = ['created_at']
    
    def complaint_count(self, obj):
        return obj.complaints.count()
    complaint_count.short_description = 'Total Complaints'
    
    def avg_resolution_time(self, obj):
        avg_time = obj.complaints.filter(
            status='RESOLVED', 
            resolution_time_hours__isnull=False
        ).aggregate(avg=Avg('resolution_time_hours'))['avg']
        
        if avg_time:
            days = round(avg_time / 24, 1)
            if days > 7:
                return format_html('<span style="color: red;">{} days</span>', days)
            elif days > 3:
                return format_html('<span style="color: orange;">{} days</span>', days)
            return f"{days} days"
        return "N/A"
    avg_resolution_time.short_description = 'Avg Resolution Time'

@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = [
        'complaint_id', 'title', 'user', 'category', 'department', 'priority_display', 
        'status_display', 'urgency', 'age_days', 'sla_status', 'satisfaction_display', 'created_at'
    ]
    list_filter = [
        'status', 'urgency', 'category', 'department', 'priority', 'sla_breached', 
        'created_at', 'resolved_at', 'assigned_to'
    ]
    search_fields = [
        'complaint_id', 'title', 'user__username', 'user__email', 
        'category__name', 'department__name', 'location'
    ]
    readonly_fields = [
        'complaint_id', 'created_at', 'updated_at', 'first_response_at',
        'in_progress_at', 'resolved_at', 'closed_at', 'escalated_at',
        'resolution_time_hours', 'age_days', 'response_time_display',
        'sla_status_display'
    ]
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('complaint_id', 'user', 'category', 'department', 'title', 'description', 'location')
        }),
        ('Priority & Assignment', {
            'fields': ('priority', 'urgency', 'assigned_to')
        }),
        ('Status & Remarks', {
            'fields': ('status', 'admin_remarks')
        }),
        ('Analytics & Tracking', {
            'fields': (
                'sla_breached', 'satisfaction_score', 'resolution_time_hours',
                'age_days', 'response_time_display', 'sla_status_display'
            ),
            'classes': ('collapse',)
        }),
        ('Timestamps', {
            'fields': (
                'created_at', 'updated_at', 'first_response_at',
                'in_progress_at', 'resolved_at', 'closed_at', 'escalated_at'
            ),
            'classes': ('collapse',)
        })
    )
    
    inlines = [ComplaintStatusHistoryInline, FeedbackInline]
    
    actions = [
        'mark_in_progress', 'mark_resolved', 'escalate_complaint', 'assign_to_me',
        'send_status_update_email', 'export_to_csv', 'calculate_metrics'
    ]
    
    def status_display(self, obj):
        color = obj.get_status_color()
        return format_html(
            '<span style="color: {}; font-weight: bold;">{}</span>',
            color, obj.get_status_display()
        )
    status_display.short_description = 'Status'
    
    def priority_display(self, obj):
        if obj.priority:
            return format_html(
                '<span style="color: {}; font-weight: bold;">{}</span>',
                obj.priority.color_code, obj.priority.name
            )
        return "Not Set"
    priority_display.short_description = 'Priority'
    
    def age_days(self, obj):
        days = obj.age_in_days
        if days > 30:
            return format_html('<span style="color: red; font-weight: bold;">{} days</span>', days)
        elif days > 14:
            return format_html('<span style="color: orange; font-weight: bold;">{} days</span>', days)
        return f"{days} days"
    age_days.short_description = 'Age'
    
    def sla_status(self, obj):
        if obj.sla_breached:
            return format_html('<span style="color: red; font-weight: bold;">BREACHED</span>')
        elif obj.is_overdue:
            return format_html('<span style="color: orange; font-weight: bold;">AT RISK</span>')
        return format_html('<span style="color: green;">OK</span>')
    sla_status.short_description = 'SLA Status'
    
    def satisfaction_display(self, obj):
        if obj.satisfaction_score:
            if obj.satisfaction_score >= 4:
                color = "green"
            elif obj.satisfaction_score >= 3:
                color = "orange"
            else:
                color = "red"
            return format_html(
                '<span style="color: {}; font-weight: bold;">{}/5</span>',
                color, obj.satisfaction_score
            )
        return "N/A"
    satisfaction_display.short_description = 'Satisfaction'
    
    def response_time_display(self, obj):
        time = obj.response_time_hours
        if time:
            if time > 24:
                return format_html('<span style="color: red;">{:.1f} hrs</span>', time)
            elif time > 8:
                return format_html('<span style="color: orange;">{:.1f} hrs</span>', time)
            return f"{time:.1f} hrs"
        return "Not responded"
    response_time_display.short_description = 'Response Time'
    
    def sla_status_display(self, obj):
        if obj.priority:
            if obj.sla_breached:
                return format_html(
                    '<span style="color: red; font-weight: bold;">SLA BREACHED ({}h limit)</span>',
                    obj.priority.sla_hours
                )
            elif obj.is_overdue:
                return format_html(
                    '<span style="color: orange; font-weight: bold;">SLA AT RISK ({}h limit)</span>',
                    obj.priority.sla_hours
                )
            return format_html(
                '<span style="color: green;">Within SLA ({}h limit)</span>',
                obj.priority.sla_hours
            )
        return "No SLA set"
    sla_status_display.short_description = 'SLA Status Detail'
    
# Enhanced Admin actions
    def mark_in_progress(self, request, queryset):
        updated_count = 0
        for complaint in queryset:
            if complaint.status == 'PENDING':
                complaint.status = 'IN_PROGRESS'
                complaint.save()
                # Create status history
                ComplaintStatusHistory.objects.create(
                    complaint=complaint,
                    old_status='PENDING',
                    new_status='IN_PROGRESS',
                    changed_by=request.user,
                    remarks='Status changed via admin bulk action'
                )
                updated_count += 1
        self.message_user(request, f'{updated_count} complaints marked as In Progress.')
    mark_in_progress.short_description = "Mark selected complaints as In Progress"
    
    def mark_resolved(self, request, queryset):
        updated_count = 0
        for complaint in queryset:
            if complaint.status in ['PENDING', 'IN_PROGRESS']:
                old_status = complaint.status
                complaint.status = 'RESOLVED'
                complaint.save()
                # Create status history
                ComplaintStatusHistory.objects.create(
                    complaint=complaint,
                    old_status=old_status,
                    new_status='RESOLVED',
                    changed_by=request.user,
                    remarks='Status changed via admin bulk action'
                )
                updated_count += 1
        self.message_user(request, f'{updated_count} complaints marked as Resolved.')
    mark_resolved.short_description = "Mark selected complaints as Resolved"
    
    def escalate_complaint(self, request, queryset):
        updated_count = 0
        for complaint in queryset:
            if complaint.status in ['PENDING', 'IN_PROGRESS']:
                old_status = complaint.status
                complaint.status = 'ESCALATED'
                complaint.save()
                # Create status history
                ComplaintStatusHistory.objects.create(
                    complaint=complaint,
                    old_status=old_status,
                    new_status='ESCALATED',
                    changed_by=request.user,
                    remarks='Complaint escalated via admin bulk action'
                )
                updated_count += 1
        self.message_user(request, f'{updated_count} complaints escalated.')
    escalate_complaint.short_description = "Escalate selected complaints"
    
    def assign_to_me(self, request, queryset):
        count = queryset.filter(assigned_to__isnull=True).update(assigned_to=request.user)
        self.message_user(request, f'{count} complaints assigned to you.')
    assign_to_me.short_description = "Assign selected complaints to me"
    
    def send_status_update_email(self, request, queryset):
        from .views import send_status_update_email
        count = 0
        for complaint in queryset:
            try:
                send_status_update_email(complaint, complaint.status)
                count += 1
            except Exception as e:
                pass
        self.message_user(request, f'Status update emails sent for {count} complaints.')
    send_status_update_email.short_description = "Send status update emails"
    
    def export_to_csv(self, request, queryset):
        import csv
        from django.http import HttpResponse
        
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = f'attachment; filename="complaints_{timezone.now().strftime("%Y%m%d_%H%M")}.csv"'
        
        writer = csv.writer(response)
        writer.writerow([
            'Complaint ID', 'Title', 'User', 'Category', 'Department', 'Status', 
            'Priority', 'Created Date', 'Age (Days)', 'SLA Status'
        ])
        
        for complaint in queryset:
            writer.writerow([
                complaint.complaint_id,
                complaint.title,
                complaint.user.username,
                complaint.category.name,
                complaint.department.name if complaint.department else 'Unassigned',
                complaint.get_status_display(),
                complaint.priority.name if complaint.priority else 'Not Set',
                complaint.created_at.strftime('%Y-%m-%d %H:%M'),
                complaint.age_in_days,
                'BREACHED' if complaint.sla_breached else 'OK'
            ])
        
        return response
    export_to_csv.short_description = "Export selected complaints to CSV"
    
    def calculate_metrics(self, request, queryset):
        # Calculate daily metrics for today
        ComplaintMetrics.calculate_daily_metrics()
        self.message_user(request, 'Daily metrics calculated successfully.')
    calculate_metrics.short_description = "Recalculate daily metrics"

@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ['complaint', 'rating_display', 'would_recommend', 'comments_preview', 'created_at']
    list_filter = ['rating', 'would_recommend', 'created_at']
    search_fields = ['complaint__complaint_id', 'comments']
    readonly_fields = ['created_at']
    
    def rating_display(self, obj):
        stars = '★' * obj.rating + '☆' * (5 - obj.rating)
        if obj.rating >= 4:
            color = "green"
        elif obj.rating >= 3:
            color = "orange" 
        else:
            color = "red"
        return format_html('<span style="color: {}; font-size: 16px;">{}</span>', color, stars)
    rating_display.short_description = 'Rating'
    
    def comments_preview(self, obj):
        if obj.comments:
            preview = obj.comments[:50] + "..." if len(obj.comments) > 50 else obj.comments
            return preview
        return "No comments"
    comments_preview.short_description = 'Comments'

@admin.register(ComplaintStatusHistory)
class ComplaintStatusHistoryAdmin(admin.ModelAdmin):
    list_display = ['complaint', 'status_change', 'changed_by', 'changed_at']
    list_filter = ['old_status', 'new_status', 'changed_at', 'changed_by']
    search_fields = ['complaint__complaint_id', 'remarks']
    readonly_fields = ['changed_at']
    date_hierarchy = 'changed_at'
    
    def status_change(self, obj):
        return format_html(
            '<span style="background: #f0f0f0; padding: 2px 5px; border-radius: 3px;">{}</span> → '
            '<span style="background: #e8f5e8; padding: 2px 5px; border-radius: 3px;">{}</span>',
            obj.old_status, obj.new_status
        )
    status_change.short_description = 'Status Change'

@admin.register(ComplaintMetrics)
class ComplaintMetricsAdmin(admin.ModelAdmin):
    list_display = [
        'date', 'new_complaints', 'resolved_complaints', 'total_active',
        'avg_resolution_display', 'sla_compliance_display', 'satisfaction_display'
    ]
    list_filter = ['date']
    readonly_fields = [
        'date', 'new_complaints', 'resolved_complaints', 'escalated_complaints',
        'total_active', 'avg_response_time_hours', 'avg_resolution_time_hours',
        'sla_compliance_rate', 'satisfaction_score', 'top_category',
        'top_category_count', 'created_at', 'updated_at'
    ]
    date_hierarchy = 'date'
    ordering = ['-date']
    
    def avg_resolution_display(self, obj):
        if obj.avg_resolution_time_hours:
            hours = obj.avg_resolution_time_hours
            days = round(hours / 24, 1)
            if days > 7:
                return format_html('<span style="color: red;">{:.1f} days</span>', days)
            elif days > 3:
                return format_html('<span style="color: orange;">{:.1f} days</span>', days)
            return f"{days:.1f} days"
        return "N/A"
    avg_resolution_display.short_description = 'Avg Resolution Time'
    
    def sla_compliance_display(self, obj):
        if obj.sla_compliance_rate is not None:
            rate = obj.sla_compliance_rate
            if rate < 70:
                color = "red"
            elif rate < 85:
                color = "orange"
            else:
                color = "green"
            return format_html('<span style="color: {}; font-weight: bold;">{:.1f}%</span>', color, rate)
        return "N/A"
    sla_compliance_display.short_description = 'SLA Compliance'
    
    def satisfaction_display(self, obj):
        if obj.satisfaction_score:
            score = obj.satisfaction_score
            if score >= 4:
                color = "green"
            elif score >= 3:
                color = "orange"
            else:
                color = "red"
            return format_html('<span style="color: {}; font-weight: bold;">{:.1f}/5</span>', color, score)
        return "N/A"
    satisfaction_display.short_description = 'Satisfaction Score'
