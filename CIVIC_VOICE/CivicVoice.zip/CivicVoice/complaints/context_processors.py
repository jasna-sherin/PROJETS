from django.contrib.auth.decorators import login_required
from django.db.models import Q
from .models import Complaint


def admin_counts(request):
    """Provide global counts for admin sidebar badges.
    Returns empty for non-staff users to avoid unnecessary queries.
    """
    user = getattr(request, 'user', None)
    if not user or not user.is_authenticated or not user.is_staff:
        return {}

    try:
        total = Complaint.objects.count()
        pending = Complaint.objects.filter(status='PENDING').count()
        in_progress = Complaint.objects.filter(status='IN_PROGRESS').count()
        resolved = Complaint.objects.filter(status='RESOLVED').count()
        unassigned = Complaint.objects.filter(assigned_to__isnull=True).count()
    except Exception:
        # Be defensive; never break template rendering
        total = pending = in_progress = resolved = unassigned = 0

    return {
        'total_complaints_count': total,
        'pending_complaints_count': pending,
        'in_progress_complaints_count': in_progress,
        'resolved_complaints_count': resolved,
        'unassigned_complaints_count': unassigned,
    }
