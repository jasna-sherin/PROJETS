from django.urls import path
from . import views, admin_views

app_name = 'complaints'

urlpatterns = [
    # Public views
    path('', views.home, name='home'),
    path('track/', views.track_complaint, name='track_complaint'),
    path('complaint/<str:complaint_id>/', views.complaint_detail, name='complaint_detail'),
    
    # User views (require login)
    path('dashboard/', views.dashboard, name='dashboard'),
    path('submit/', views.submit_complaint, name='submit_complaint'),
    path('my-complaints/', views.my_complaints, name='my_complaints'),
    path('feedback/<str:complaint_id>/', views.give_feedback, name='give_feedback'),
    
    # Admin views (staff only)
    path('admin/', admin_views.admin_dashboard, name='admin_dashboard'),
    path('admin/complaints/', admin_views.complaint_list, name='complaint_list'),
    path('admin/complaints/<str:complaint_id>/', admin_views.complaint_detail, name='admin_complaint_detail'),
    path('admin/feedback/', admin_views.feedback_list, name='feedback_list'),
    path('admin/reports/', admin_views.reports_view, name='reports_view'),
    path('ajax/update-status/', admin_views.ajax_update_status, name='ajax_update_status'),
]
