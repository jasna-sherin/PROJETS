from django import forms
from .models import Complaint, Feedback, Category

class ComplaintForm(forms.ModelForm):
    class Meta:
        model = Complaint
        fields = ['category', 'title', 'description', 'location']
        widgets = {
            'category': forms.Select(attrs={'class': 'form-control'}),
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Brief title for your complaint'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 5, 'placeholder': 'Describe your complaint in detail'}),
            'location': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Location where the issue occurred'}),
        }

class ComplaintStatusForm(forms.ModelForm):
    """Form for admin to update complaint status and remarks"""
    class Meta:
        model = Complaint
        fields = ['status', 'admin_remarks']
        widgets = {
            'status': forms.Select(attrs={'class': 'form-control'}),
            'admin_remarks': forms.Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': 'Add remarks about the complaint status or actions taken'}),
        }

class FeedbackForm(forms.ModelForm):
    class Meta:
        model = Feedback
        fields = ['rating', 'comments']
        widgets = {
            'rating': forms.RadioSelect(attrs={'class': 'form-check-input'}),
            'comments': forms.Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': 'Share your feedback about the resolution (optional)'}),
        }

class ComplaintSearchForm(forms.Form):
    complaint_id = forms.CharField(
        max_length=25,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter Complaint ID (e.g., CV20250928-ABC123)'
        }),
        label='Complaint ID'
    )

class ReportFilterForm(forms.Form):
    """Form for filtering reports by various criteria"""
    REPORT_TYPE_CHOICES = [
        ('category', 'By Category'),
        ('status', 'By Status'),
        ('date_range', 'By Date Range'),
        ('overall', 'Overall Summary'),
    ]
    
    report_type = forms.ChoiceField(
        choices=REPORT_TYPE_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'}),
        label='Report Type'
    )
    
    category = forms.ModelChoiceField(
        queryset=Category.objects.all(),
        required=False,
        empty_label="All Categories",
        widget=forms.Select(attrs={'class': 'form-control'}),
        label='Category Filter'
    )
    
    status = forms.ChoiceField(
        choices=[('', 'All Statuses')] + Complaint.STATUS_CHOICES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'}),
        label='Status Filter'
    )
    
    date_from = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        }),
        label='From Date'
    )
    
    date_to = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        }),
        label='To Date'
    )
