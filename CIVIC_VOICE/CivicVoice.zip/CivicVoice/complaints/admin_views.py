from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Q, Count, Avg
from django.core.paginator import Paginator
from django.utils import timezone
from django.conf import settings
from .models import Complaint, Category, Feedback
from .views import send_status_update_email

def is_staff(user):
    """Check if user is staff member"""
    return user.is_authenticated and user.is_staff

@user_passes_test(is_staff)
def admin_dashboard(request):
    """Main admin dashboard with statistics and overview"""
    # Get statistics
    stats = {
        'total_complaints': Complaint.objects.count(),
        'pending_complaints': Complaint.objects.filter(status='PENDING').count(),
        'in_progress_complaints': Complaint.objects.filter(status='IN_PROGRESS').count(),
        'resolved_complaints': Complaint.objects.filter(status='RESOLVED').count(),
    }
    
    # Recent complaints (last 10)
    recent_complaints = Complaint.objects.select_related('user', 'category').order_by('-created_at')[:10]
    
    # Category breakdown
    category_stats = Category.objects.annotate(
        complaint_count=Count('complaints')
    ).order_by('-complaint_count')[:5]
    
    # Recent feedback
    recent_feedback = Feedback.objects.select_related('complaint', 'complaint__user').order_by('-created_at')[:5]
    
    context = {
        'stats': stats,
        'recent_complaints': recent_complaints,
        'category_stats': category_stats,
        'recent_feedback': recent_feedback,
    }
    return render(request, 'admin/dashboard.html', context)

@user_passes_test(is_staff)
def complaint_list(request):
    """List all complaints with filtering and search"""
    complaints = Complaint.objects.select_related('user', 'category').order_by('-created_at')
    
    # Get filter parameters
    status = request.GET.get('status')
    category_id = request.GET.get('category')
    search = request.GET.get('search')
    
    # Apply filters
    if status:
        complaints = complaints.filter(status=status)
    if category_id:
        complaints = complaints.filter(category_id=category_id)
    if search:
        complaints = complaints.filter(
            Q(complaint_id__icontains=search) |
            Q(title__icontains=search) |
            Q(user__username__icontains=search) |
            Q(user__email__icontains=search) |
            Q(location__icontains=search)
        )
    
    # Pagination
    paginator = Paginator(complaints, 20)  # Show 20 complaints per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    # Get categories for filter dropdown
    categories = Category.objects.all()
    
    context = {
        'page_obj': page_obj,
        'categories': categories,
        'current_status': status,
        'current_category': int(category_id) if category_id else None,
        'current_search': search,
        'status_choices': Complaint.STATUS_CHOICES,
    }
    return render(request, 'admin/complaint_list.html', context)

@user_passes_test(is_staff)
def complaint_detail(request, complaint_id):
    """View and manage individual complaint"""
    complaint = get_object_or_404(Complaint, complaint_id=complaint_id)
    
    # Handle status update
    if request.method == 'POST':
        new_status = request.POST.get('status')
        admin_remarks = request.POST.get('admin_remarks')
        
        if new_status and new_status in dict(Complaint.STATUS_CHOICES):
            old_status = complaint.status
            complaint.status = new_status
            if admin_remarks:
                complaint.admin_remarks = admin_remarks
            complaint.save()
            
            # Create status history entry
            from .models import ComplaintStatusHistory
            ComplaintStatusHistory.objects.create(
                complaint=complaint,
                old_status=old_status,
                new_status=new_status,
                changed_by=request.user,
                remarks=admin_remarks or f'Status changed from {old_status} to {new_status}'
            )
            
            # Send status update email (only if enabled)
            if getattr(settings, 'ENABLE_EMAIL_NOTIFICATIONS', True):
                try:
                    send_status_update_email(complaint, old_status)
                    messages.success(request, f'Complaint status updated to {complaint.get_status_display()}. Email notification sent to user.')
                except Exception as e:
                    messages.warning(request, f'Complaint status updated to {complaint.get_status_display()}, but email notification failed.')
            else:
                messages.success(request, f'Complaint status updated to {complaint.get_status_display()}.')
            
            return redirect('complaints:admin_complaint_detail', complaint_id=complaint.complaint_id)
    
    # Get feedback if exists
    try:
        feedback = Feedback.objects.get(complaint=complaint)
    except Feedback.DoesNotExist:
        feedback = None
    
    context = {
        'complaint': complaint,
        'feedback': feedback,
        'status_choices': Complaint.STATUS_CHOICES,
    }
    return render(request, 'admin/complaint_detail.html', context)

@user_passes_test(is_staff)
def feedback_list(request):
    """List all feedback with ratings and comments"""
    feedback_list = Feedback.objects.select_related('complaint', 'complaint__user', 'complaint__category').order_by('-created_at')
    
    # Filter by rating
    rating = request.GET.get('rating')
    if rating:
        feedback_list = feedback_list.filter(rating=rating)
    
    # Pagination
    paginator = Paginator(feedback_list, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    # Calculate average rating
    avg_rating = Feedback.objects.aggregate(avg_rating=Avg('rating'))['avg_rating'] or 0
    
    context = {
        'page_obj': page_obj,
        'current_rating': int(rating) if rating else None,
        'avg_rating': round(avg_rating, 2),
        'rating_choices': [(i, i) for i in range(1, 6)],
    }
    return render(request, 'admin/feedback_list.html', context)

@user_passes_test(is_staff)
def reports_view(request):
    """Generate basic reports"""
    # Status distribution
    status_stats = {}
    for status, label in Complaint.STATUS_CHOICES:
        status_stats[label] = Complaint.objects.filter(status=status).count()
    
    # Category distribution
    category_stats = Category.objects.annotate(
        complaint_count=Count('complaints')
    ).order_by('-complaint_count')
    
    # Monthly stats (last 12 months)
    monthly_stats = []
    for i in range(12):
        date = timezone.now().replace(day=1) - timezone.timedelta(days=30*i)
        month_complaints = Complaint.objects.filter(
            created_at__year=date.year,
            created_at__month=date.month
        ).count()
        monthly_stats.append({
            'month': date.strftime('%B %Y'),
            'count': month_complaints
        })
    monthly_stats.reverse()
    
    # Feedback statistics
    feedback_stats = {
        'total_feedback': Feedback.objects.count(),
        'avg_rating': Feedback.objects.aggregate(avg_rating=Avg('rating'))['avg_rating'] or 0,
        'five_star': Feedback.objects.filter(rating=5).count(),
        'four_star': Feedback.objects.filter(rating=4).count(),
        'three_star': Feedback.objects.filter(rating=3).count(),
        'two_star': Feedback.objects.filter(rating=2).count(),
        'one_star': Feedback.objects.filter(rating=1).count(),
    }
    
    context = {
        'status_stats': status_stats,
        'category_stats': category_stats,
        'monthly_stats': monthly_stats,
        'feedback_stats': feedback_stats,
    }
    return render(request, 'admin/reports.html', context)

@user_passes_test(is_staff)
def ajax_update_status(request):
    """AJAX endpoint to update complaint status"""
    if request.method == 'POST':
        complaint_id = request.POST.get('complaint_id')
        new_status = request.POST.get('status')
        
        try:
            complaint = Complaint.objects.get(complaint_id=complaint_id)
            old_status = complaint.status
            
            if new_status in dict(Complaint.STATUS_CHOICES):
                complaint.status = new_status
                complaint.save()
                
                # Create status history entry
                from .models import ComplaintStatusHistory
                ComplaintStatusHistory.objects.create(
                    complaint=complaint,
                    old_status=old_status,
                    new_status=new_status,
                    changed_by=request.user,
                    remarks=f'Quick status change from {old_status} to {new_status}'
                )
                
                # Try to send email notification only if enabled
                if getattr(settings, 'ENABLE_EMAIL_NOTIFICATIONS', True):
                    try:
                        send_status_update_email(complaint, old_status)
                        email_sent = True
                    except Exception:
                        email_sent = False
                else:
                    email_sent = False
                
                return JsonResponse({
                    'success': True,
                    'message': f'Status updated to {complaint.get_status_display()}',
                    'email_sent': email_sent
                })
            else:
                return JsonResponse({'success': False, 'error': 'Invalid status'})
                
        except Complaint.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Complaint not found'})
    
    return JsonResponse({'success': False, 'error': 'Invalid request'})