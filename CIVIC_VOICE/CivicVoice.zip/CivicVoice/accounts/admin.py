from django.contrib import admin
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.db.models import Avg
from .models import UserProfile
from complaints.models import Complaint, Feedback


class UserProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name_plural = 'Profile'


class ComplaintInline(admin.TabularInline):
    model = Complaint
    fk_name = 'user'
    fields = ('complaint_id', 'title', 'status', 'priority', 'created_at', 'resolved_at', 'feedback_rating')
    readonly_fields = ('complaint_id', 'title', 'status', 'priority', 'created_at', 'resolved_at', 'feedback_rating')
    extra = 0
    can_delete = False

    def feedback_rating(self, obj):
        try:
            return obj.feedback.get_rating_display()
        except Feedback.DoesNotExist:
            return '—'
    feedback_rating.short_description = 'Feedback'


class UserAdmin(BaseUserAdmin):
    inlines = (UserProfileInline, ComplaintInline)
    list_display = BaseUserAdmin.list_display + ('feedback_count', 'avg_feedback')

    def feedback_count(self, obj):
        return Feedback.objects.filter(complaint__user=obj).count()
    feedback_count.short_description = 'Feedbacks'

    def avg_feedback(self, obj):
        data = Feedback.objects.filter(complaint__user=obj).aggregate(avg=Avg('rating'))
        avg = data['avg'] or 0
        return round(avg, 2)
    avg_feedback.short_description = 'Avg Rating'


# Re-register UserAdmin
admin.site.unregister(User)
admin.site.register(User, UserAdmin)
